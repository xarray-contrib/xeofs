"""
"This" is my example-script
===========================

This example doesn't do much, it just makes a simple plot
"""
